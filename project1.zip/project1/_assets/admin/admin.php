<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <!-- <link rel="stylesheet" href="../main.css"> -->
    <link rel="stylesheet" href="./admin.css">
</head>

<body>

    <div class="heading">
        <h1>THIS PAGE ONLY FOR ADMIN</h1>
    </div>
    <section class="main_section">
        <aside class="side_manu_section">
            <div class="header">
                <img src="../../_images/nav_logo.jpg" alt="logo">
                <h1>Admin</h1>
                <span class="hambarger">
                    <span class="hambarger_stick"></span>
                    <span class="hambarger_stick"></span>
                </span>
            </div>
            <div class="manu">
                <ul class="admin_manu_ul">
                    <a href="#" class="manu_bar_item_link">
                        <li class="manu_item">
                        Dashboard</li>
                        <i class="fa-thin fa-chart-line-down" style="color: white;"></i>
                    </a>
                    <a href="#" class="manu_bar_item_link">
                        <li class="manu_item">Exist Admin</li>
                    </a>
                    <a href="#" class="manu_bar_item_link">
                        <li class="manu_item">Create Admin</li>
                    </a>
                    <a href="#" class="manu_bar_item_link">
                        <li class="manu_item">Update Product</li>
                    </a>
                    <a href="#" class="manu_bar_item_link">
                        <li class="manu_item">Product Catagory</li>
                    </a>
                    <a href="#" class="manu_bar_item_link">
                        <li class="manu_item">Product Catagory</li>
                    </a>

                </ul>
            </div>
        </aside>
        <i class="fa-thin fa-chart-line-down"></i>
        <div class="containt_section"></div>
    </section>
    <script src="https://kit.fontawesome.com/37f9d47857.js" crossorigin="anonymous"></script>

</body>

</html>