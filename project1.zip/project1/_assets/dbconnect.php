<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bikreta";
$connection = mysqli_connect($servername, $username, $password, $dbname);
?>