<?php
if($_SERVER['REQUEST_METHOD']=['GET']){
    $catagory=$_GET['samsung'];
    echo $catagory;
    // header('location:../index.html');
}



?>