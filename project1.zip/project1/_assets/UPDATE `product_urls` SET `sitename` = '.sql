UPDATE `product_urls` SET `sitename` = 'flipkartf' WHERE `product_urls`.`slno` = 1;
$sql = "UPDATE `product_urls` SET `sitename` = \'flipkart\' WHERE `product_urls`.`slno` = 1;";

$sql = "UPDATE `product_urls` SET `producturl` = \'$url\', `sitename` = \'$sitename\' WHERE `product_urls`.`slno` = 1;";



UPDATE `product` SET `ProductLink` = '' WHERE `product`.`slno` = 7;


catagory=Electronics&minimum_price=0&maximum_price=1000&redmi=on&realme=on&samsung=on&sony=on&ram3gb=on&ram%24gb=on&ram6gb=on&ram8gb=on&ram3gb=on&ram3gb=on&ram3gb=on&ram3gb=on


yhB1nd
yhB1nd


CEmiEU
CEmiEU

_2418kt
_2418kt

_396cs4
_396cs4