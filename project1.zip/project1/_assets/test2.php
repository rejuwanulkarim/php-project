<!-- 

// curl_init();
// curl_setopt();
// curl_exec();
// curl_close();
// curl_exec();
// curl_close();
$url="https://www.amazon.in/Acer-Aspire-Laptop-Intel-core/dp/B0B93YP1K1/ref=sr_1_1_sspa?adgrpid=132062713609&gclid=Cj0KCQjwqc6aBhC4ARIsAN06NmON31W8TcJRpzTdTnCVapGani2LQ7H00kVljDsUMg8wcdWYkOPgbUwaAtN3EALw_wcB&hvadid=558698243642&hvdev=c&hvlocphy=9061848&hvnetw=g&hvqmt=e&hvrand=14935955701036510996&hvtargid=kwd-1908269185392&hydadcr=25631_1900937&keywords=asus+vivobook+12+gen&qid=1666451255&qu=eyJxc2MiOiIzLjQ4IiwicXNhIjoiMi4yMCIsInFzcCI6IjAuMDAifQ%3D%3D&sr=8-1-spons&psc=1";
// $image="image.jpg";

// $fimage=fopen($image,"w+");
// $ch=curl_init();
// curl_setopt($ch,CURLOPT_URL,$url);
// // curl_setopt($ch,CURLOPT_RETURNTRANSFER,TRUE);

// curl_exec($ch);
// // echo $result;
// curl_close($ch);
// fclose($fimage);
include "./simple_html_dom.php";
// $html=file_get_html("http://www.amazon.in/Samsung-Galaxy-Cloud-128GB-Storage/dp/B08VB2MRF8?ref_=Oct_DLandingS_D_95f1de40_61&smid=A14CZOWI0VEHLG&th=1");
// $big=$html->find('.a-unordered-list',0)->plaintext;
// echo $big;
$filename = "https://www.amazon.in/gp/product/B01NAKTR2H/ref=s9u_simh_gw_i1?ie=UTF8&pd_rd_i=B01NAKTR2H&pd_rd_r=ER7JC478623JY4PD7JK1&pd_rd_w=MPVuz&pd_rd_wg=M61fL&pf_rd_m=A1VBAL9TL5WCBF&pf_rd_s=&pf_rd_r=QFR3Z1PGBWZPJY1NNHQV&pf_rd_t=36701&pf_rd_p=a66bc199-b270-44de-9fcc-5cf0a06a7727&pf_rd_i=desktop";
$html = file_get_contents($filename);
$dom = new DOMDocument();
@$dom->loadHTML($html);
$element = $dom->getElementById("priceblock_dealprice");
$price = $element->nodeValue;
$price_array = explode(" ",$price);
$price_str = $price_array[1];
$price_int = (int)str_replace(",","", trim($price_str));
if($price_int<30000){//Users Predfined Amount
    echo "You Can But It";
    //You can also send user notficatio or email that the price is within their range
    //Or store in database
  }else{
    echo "Don't Buy it.<br/>It's Too Costly.";
  }
// echo $match[1]; -->
