<?php
$servername = "localhost";
$username = "epiz_33641340";
$password = "TbHbpiobTAiRll";
$dbname = "epiz_33641340_mystore";
$connection = mysqli_connect($servername, $username, $password, $dbname);
