// this script is for user page
// for customer list
const MyApi = "7b951ca15de226dfaf51232374a150eb";
// price list
const price = { black_print: 2, color_print: 7 };

let username = document.getElementsByClassName("username");
let alertSec = document.getElementById("alert");

function alHide() {
  alertSec.style.display = "none";
}

function alShow() {
  alertSec.style.display = "block";
}
// print payment recipt function
function printRecipt(val) {
  let newWindow = window.open("", "", "width=256,height=256", "_top");
  //   newWindow.name="newWindow"
  newWindow.document.write(`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet   " href="../assets/style.css">
    <title>Recipt</title>
</head>
<body>

<div class="card">
${val.parentElement.innerHTML}

</div>
<button onclick="window.print()">Print</button>
</body>
</html>`);
}
// fetch all details about customer
const customerDetails = () => {
  // console.log(formValues);
  let output = { action: "read" };

  fetch("../api/crud.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/text",
      "X-API-Key": MyApi,
    },
    body: JSON.stringify(output),
  })
    .then((response) => response.json())
    .then((result) => {
      let Allcustomer = document.getElementsByClassName("user-cards")[0];
      let userCard = "";
      if (result.status == "success") {
        for (let i in result.data) {
          userCard += `  <div class="card">
        <p class="username">${result.data[i].name}</p>
        <p>${result.data[i].email}</p>
        <p>${result.data[i].phone_no}</p>
        <p>color print:&nbsp;${result.data[i].color_print}&nbsp;pice</p>
        <p>Black and White print:&nbsp;${result.data[i].black_print}&nbsp;pice</p>
        <p>Payment Mode :&nbsp; ${result.data[i].payment_type}</p>
        <p>Total Price: <b style="color:red;">₹&nbsp;${result.data[i].total_price}</b></p>
        <p>Date: ${result.data[i].date}</p>
        <button onclick="printRecipt(this)" class="recipt-print">Print Recipt</button>

    </div>`;
        }
        Allcustomer.innerHTML = userCard;
      } else {
        alShow();
      }
    })
    .catch((err) => {
      console.log(err);
    });
};

const search = (val) => {
  for (let i = 0; i < username.length; i++) {
    username[i].parentElement.style.display = "none";
    if (val.toLowerCase() == username[i].innerHTML.toLowerCase()) {
      username[i].parentElement.style.display = "flex";
      alHide();
    } else if (val == "") {
      for (let i = 0; i < username.length; i++) {
        username[i].parentElement.style.display = "flex";
      }
      alHide();
    } else {
      alShow();
    }
  }
};
// for add new customer
let alert_msg = document.getElementsByClassName("alert-msg-nor")[0];
let addForm = document.getElementsByClassName("customer-form");
addForm[0].addEventListener("submit", (e) => {
  e.preventDefault();
  let formData = new FormData(addForm[0]);
  let name = formData.get("name");
  let phone = formData.get("phone_no");
  let colorPrint = formData.get("color_print");
  let blackPrint = formData.get("black_print");
  let paymentType = formData.get("payment_type");
  //   form value in a json
  let totalPrice =
    colorPrint * price.black_print + blackPrint * price.color_print;
  console.log(totalPrice);
  let formValues = {
    name: name,
    phone: phone,
    color_print: colorPrint,
    black_print: blackPrint,
    payment_type: paymentType,
    total: totalPrice,
  };
  let output = { data: formValues, action: "write" };
  fetch("../api/crud.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/text",
      "X-API-Key": "7b951ca15de226dfaf51232374a150eb",
    },
    body: JSON.stringify(output),
  })
    .then((response) => response.json())
    .then((result) => {
      let masssage = document.getElementById("massage");
      if (result.status == "success") {
        addForm[0].reset();
        customerDetails();
        alert_msg.classList.toggle("alert-msg-exi");
        masssage.innerHTML = "<b>Success!</b> User Added Success";
        alert_msg.style.backgroundColor = "green";
        setTimeout(() => {
          alert_msg.classList.toggle("alert-msg-exi");
        }, 2000);
      } else {
        masssage.innerHTML = "<b>Sorry!</b> User Not Added";
        alert_msg.style.backgroundColor = "red";
      }
    })
    .catch((err) => {
      console.log(err);
    });
});

// forgot otp sender

function forgotOtp(e) {
  let loading = document.getElementById("loading");
  loading.style.display = "flex";
  let email = e.previousElementSibling.value;
  if (email != "") {
    let data = { email: email };
    let output = { action: "forgot", data: data };

    fetch("../api/crud.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/text",
        "X-API-Key": "7b951ca15de226dfaf51232374a150eb",
      },
      body: JSON.stringify(output),
    })
      .then((response) => response.json())
      .then((result) => {
        console.log(result);
        if (result.status == "success") {
          loading.style.display = "none";
          let alert_msg_nor = document.getElementsByClassName("alert-msg-nor");
          alert_msg_nor[0].classList.toggle("alert-msg-exi");
          alert_msg_nor[0].innerHTML = `<b>OTP Send Successfully</b>`;
          setTimeout(() => {
            alert_msg_nor[0].classList.toggle("alert-msg-exi");
          }, 3000);
        } else {
          alert_msg_nor[0].innerHTML = `<b>Sorry OTP Not Sent</b>`;
          setTimeout(() => {
            alert_msg_nor[0].classList.toggle("alert-msg-exi");
          }, 3000);
          alert_msg_nor[0].style.backgroundColor = "red";
        }
      })
      .catch((err) => {
        alert_msg_nor[0].innerHTML = `<b>Sorry some error occurred</b>`;
        loading.style.display = "none";
        setTimeout(() => {
          alert_msg_nor[0].classList.toggle("alert-msg-exi");
        }, 3000);
      });
  }
}
