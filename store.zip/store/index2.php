<?php
session_start();
$_SESSION['time'] = 15;
$time = strtotime("now");
echo $time."<br>";
echo $time + (10 * 60000);

// if ($time == $time + (10 * 60000)) {
//     echo "time up";
//     $_SESSION['time'] = 0;
// }
// if ($_SESSION['time'] == 0) {
//     header("location:./about.php");
// }

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recipt</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>

<body>
    <table>
        <tr></tr>
    </table>

</body>

</html>