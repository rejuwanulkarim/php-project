<?php
$api_key = "7b951ca15de226dfaf51232374a150eb";
$accept_header = $_SERVER['HTTP_X_API_KEY'];

if ($accept_header == $api_key) {
    include "../connections/connections.php";
    $json = file_get_contents('php://input');
    $decoded = json_decode($json, true);
    $query = $decoded['action'];
    if ($query == "read") {
        $sql = "SELECT * FROM `mystore`  ORDER BY slno DESC";
        $result = mysqli_query($connection, $sql);
        if (mysqli_num_rows($result) > 0) {
            $output = [];
            while ($row = mysqli_fetch_assoc($result)) {
                $output[] = $row;
            }
            echo json_encode(array("status" => "success", "data" => $output));
            mysqli_close($connection);
        } else {
            echo json_encode(array("status" => "empty"));
            mysqli_close($connection);
        }
    } elseif ($query == "write") {
        $data = $decoded['data'];
        $name = $data['name'];
        $phone_no = $data['phone'];
        $color_print = $data['color_print'];
        $black_print = $data['black_print'];
        $payment_type = $data['payment_type'];
        $total_price = $data['total'];
        $sql = "INSERT INTO `mystore` (`name`,`phone_no`,`color_print`,`black_print`,`payment_type`,`total_price`,`date`) VALUES ('$name','$phone_no','$color_print','$black_print','$payment_type','$total_price',CURRENT_TIME())";
        $result = mysqli_query($connection, $sql);
        if ($result) {
            echo json_encode(array("status" => "success"));
        } else {
            echo json_encode(array("status" => "error"));
        }
    } elseif ($query == "forgot") {
        include "../connections/connections.php";
        $data = $decoded['data'];
        $email = $data['email'];
        $sql = "SELECT * FROM `authentication` WHERE `username`='$email'";
        $result = mysqli_query($connection, $sql);
        if (mysqli_num_rows($result) > 0) {

            $otp = rand(100000, 999999);
            $Update_sql = "UPDATE `authentication` SET `OTP` = '$otp' WHERE `authentication`.`username`='$email'";
            $result = mysqli_query($connection, $Update_sql);

            if ($result) {
                require_once("../api/smtp/PHPMailerAutoload.php");
                $mail = new PHPMailer(true);
                $mail->isSMTP();
                $mail->Host = "smtp.gmail.com";
                $mail->Port = 587;
                $mail->SMTPSecure = "tls";
                $mail->SMTPAuth = true;
                $mail->Username = "karimdr341@gmail.com";
                $mail->Password = "fakqlhcursmxyjmy";
                $mail->SetFrom("karimdr341@gmail.com");
                $mail->addAddress("$email");
                $mail->IsHTML(true);
                $mail->Subject = "OTP";
                $mail->Body = "OTP is $otp";
                $mail->SMTPOptions = array('ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => false
                ));
                if ($mail->send()) {
                    echo json_encode(array("status" => "success"));
                    mysqli_close($connection);
                } else {
                    echo json_encode(array("status" => "error"));
                    mysqli_close($connection);
                }
            } else {
                echo json_encode(array("status" => "error"));
                mysqli_close($connection);
            }
            // echo json_encode(array("status" => "success"));
        } else {
            echo json_encode("un success");
        }
    }
} else {

    echo json_encode("invalid User");
}
