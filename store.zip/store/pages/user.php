<?php
session_start();
$login = $_SESSION['logedin'];
$slno = $_SESSION['slno'];
$profile = $_SESSION['profile'];
if ($login != true) {
    header("location:../index.php");
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User</title>
    <link rel="stylesheet" href="../assets/style.css">
    <link rel="stylesheet" href="../assets/nav.css">
</head>

<body onload="customerDetails()">
    <?php
    include "./navbar.php";
    ?>
    <div class="alert-msg-nor">
        <div id="massage"></div>
    </div>
    <section class="user-details">
        <div class="user-adder">
            <h3 class="heading">Add Customer</h3>
            <form action="./user.php" class="customer-form" method="post">
                <input type="text" name="name" id="customer-name" class="login-inputs user-add-inputs" placeholder="Enter Customer Name" required>
                <input type="number" name="phone_no" id="customer-phoneno" class="login-inputs user-add-inputs" placeholder="Enter Customer Phone No" required>
                <input type="number" name="color_print" id="color-print" class="login-inputs user-add-inputs" placeholder="Total Color Print" value="0" required>
                <input type="number" name="black_print" id="black-white-print" class="login-inputs user-add-inputs" placeholder="Total Black and White Print" value="0" required>
                <div class="payment">
                    <label for="Payment Type">Payment Type:&nbsp;</label>
                    <input type="radio" name="payment_type" id="payment-type" class="payment-type user-add-inputs" value="Online">
                    <input type="radio" name="payment_type" id="payment-type" class="payment-type user-add-inputs" value="Offline">
                </div>

                <button type="submit" id="add-btn" class="submit">Add +</button>
            </form>
        </div>
        <div class="user-lists">
            <h3 class="heading">Customer Details</h3>
            <div class="user-search">
                <input type="text" name="search" id="search" oninput="search(this.value)" placeholder="Search By Name..." width="80%">
                <button id="customer-reloader" onclick="customerDetails()">Reload Data</button>
            </div>
            <div class="user-cards">
                <!-- this card comment only for backup card -->
                <!-- <div class="card">
                    <p class="username">Md Rejuwanul Karim</p>
                    <p>rejuwanulkarim@gmail.com</p>
                    <p>7478919026</p>
                    <p>color print:&nbsp;15pice</p>
                    <p>Black and White print:&nbsp;15pice</p>
                    <p>Payment Mode :&nbsp; Online</p>
                    <p>Date: 10-02-2003</p>

                </div>-->

                <div id="alert">No customer Found:)</div>

            </div>
        </div>
    </section>






    <script src="../assets/main.js"></script>
</body>

</html>